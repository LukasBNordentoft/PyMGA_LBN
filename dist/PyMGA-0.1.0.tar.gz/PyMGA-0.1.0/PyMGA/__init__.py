__version__ = "0.0.1"

import PyMGA.methods
import PyMGA.cases
